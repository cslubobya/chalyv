Manual
======

Most filters are self explained. Click the "config" button for more information on each filter.


**Intra Display Filter**

Planar  -- Circle

DC	    -- Top-left sector

Angular -- Line

